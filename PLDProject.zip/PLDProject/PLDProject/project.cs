﻿
using System;
using System.IO;
using System.Runtime.Serialization;
using com.calitha.goldparser.lalr;
using com.calitha.commons;
using System.Windows.Forms;

namespace com.calitha.goldparser
{

    [Serializable()]
    public class SymbolException : System.Exception
    {
        public SymbolException(string message) : base(message)
        {
        }

        public SymbolException(string message,
            Exception inner) : base(message, inner)
        {
        }

        protected SymbolException(SerializationInfo info,
            StreamingContext context) : base(info, context)
        {
        }

    }

    [Serializable()]
    public class RuleException : System.Exception
    {

        public RuleException(string message) : base(message)
        {
        }

        public RuleException(string message,
                             Exception inner) : base(message, inner)
        {
        }

        protected RuleException(SerializationInfo info,
                                StreamingContext context) : base(info, context)
        {
        }

    }

    enum SymbolConstants : int
    {
        SYMBOL_EOF                   =  0, // (EOF)
        SYMBOL_ERROR                 =  1, // (Error)
        SYMBOL_WHITESPACE            =  2, // Whitespace
        SYMBOL_MINUS                 =  3, // '-'
        SYMBOL_EXCLAMEQ              =  4, // '!='
        SYMBOL_TIMES                 =  5, // '*'
        SYMBOL_DIV                   =  6, // '/'
        SYMBOL_COLON                 =  7, // ':'
        SYMBOL_SEMI                  =  8, // ';'
        SYMBOL_PLUS                  =  9, // '+'
        SYMBOL_LT                    = 10, // '<'
        SYMBOL_LTMINUS               = 11, // '<-'
        SYMBOL_LTEQ                  = 12, // '<='
        SYMBOL_EQEQ                  = 13, // '=='
        SYMBOL_GT                    = 14, // '>'
        SYMBOL_GTEQ                  = 15, // '>='
        SYMBOL_BOOLEAN               = 16, // boolean
        SYMBOL_CASE                  = 17, // case
        SYMBOL_DEFAULT               = 18, // default
        SYMBOL_DO                    = 19, // do
        SYMBOL_ELIF                  = 20, // elif
        SYMBOL_ELSE                  = 21, // else
        SYMBOL_ENDFOR                = 22, // endfor
        SYMBOL_ENDLOOP               = 23, // endloop
        SYMBOL_ENDPROGRAM            = 24, // EndProgram
        SYMBOL_ENDSWITCH             = 25, // endswitch
        SYMBOL_ENDWHILE              = 26, // endwhile
        SYMBOL_FLOAT                 = 27, // float
        SYMBOL_FOR                   = 28, // for
        SYMBOL_IDENTIFIER            = 29, // identifier
        SYMBOL_IF                    = 30, // if
        SYMBOL_INT                   = 31, // int
        SYMBOL_LOOP                  = 32, // loop
        SYMBOL_PROGRAM               = 33, // Program
        SYMBOL_STRING                = 34, // string
        SYMBOL_SWITCH                = 35, // switch
        SYMBOL_THEN                  = 36, // then
        SYMBOL_TO                    = 37, // to
        SYMBOL_WHILE                 = 38, // while
        SYMBOL_ARITHMETIC_EXPRESSION = 39, // <arithmetic_expression>
        SYMBOL_ASSIGNMENT            = 40, // <assignment>
        SYMBOL_CASE_CLAUSE           = 41, // <case_clause>
        SYMBOL_CONDITIONAL           = 42, // <conditional>
        SYMBOL_DO_WHILE_LOOP         = 43, // <do_while_loop>
        SYMBOL_ELIF_CLAUSE           = 44, // <elif_clause>
        SYMBOL_ELSE_CLAUSE           = 45, // <else_clause>
        SYMBOL_EXPRESSION            = 46, // <expression>
        SYMBOL_FOR_LOOP              = 47, // <for_loop>
        SYMBOL_LOGICAL_EXPRESSION    = 48, // <logical_expression>
        SYMBOL_LOOP2                 = 49, // <loop>
        SYMBOL_PROGRAM2              = 50, // <program>
        SYMBOL_STATEMENT             = 51, // <statement>
        SYMBOL_STATEMENT_LIST        = 52, // <statement_list>
        SYMBOL_SWITCH_CASE           = 53, // <switch_case>
        SYMBOL_VALUE                 = 54, // <value>
        SYMBOL_WHILE_LOOP            = 55  // <while_loop>
    };

    enum RuleConstants : int
    {
        RULE_PROGRAM_PROGRAM_ENDPROGRAM                   =  0, // <program> ::= Program <statement_list> EndProgram
        RULE_STATEMENT_LIST_SEMI                          =  1, // <statement_list> ::= <statement> ';' <statement_list>
        RULE_STATEMENT_LIST                               =  2, // <statement_list> ::= <statement>
        RULE_STATEMENT                                    =  3, // <statement> ::= <assignment>
        RULE_STATEMENT2                                   =  4, // <statement> ::= <conditional>
        RULE_STATEMENT3                                   =  5, // <statement> ::= <loop>
        RULE_STATEMENT4                                   =  6, // <statement> ::= <for_loop>
        RULE_STATEMENT5                                   =  7, // <statement> ::= <while_loop>
        RULE_STATEMENT6                                   =  8, // <statement> ::= <do_while_loop>
        RULE_STATEMENT7                                   =  9, // <statement> ::= <switch_case>
        RULE_ASSIGNMENT_IDENTIFIER_LTMINUS                = 10, // <assignment> ::= identifier '<-' <expression>
        RULE_CONDITIONAL_IF_THEN                          = 11, // <conditional> ::= if <expression> then <statement_list> <elif_clause> <else_clause>
        RULE_ELIF_CLAUSE_ELIF_THEN                        = 12, // <elif_clause> ::= elif <expression> then <statement_list> <elif_clause>
        RULE_ELIF_CLAUSE                                  = 13, // <elif_clause> ::= 
        RULE_ELSE_CLAUSE_ELSE_THEN                        = 14, // <else_clause> ::= else then <statement_list>
        RULE_ELSE_CLAUSE                                  = 15, // <else_clause> ::= 
        RULE_LOOP_LOOP_DO_ENDLOOP                         = 16, // <loop> ::= loop <expression> do <statement_list> endloop
        RULE_FOR_LOOP_FOR_IDENTIFIER_LTMINUS_TO_DO_ENDFOR = 17, // <for_loop> ::= for identifier '<-' <expression> to <expression> do <statement_list> endfor
        RULE_WHILE_LOOP_WHILE_DO_ENDWHILE                 = 18, // <while_loop> ::= while <expression> do <statement_list> endwhile
        RULE_DO_WHILE_LOOP_DO_WHILE                       = 19, // <do_while_loop> ::= do <statement_list> while <expression>
        RULE_SWITCH_CASE_SWITCH_IDENTIFIER_ENDSWITCH      = 20, // <switch_case> ::= switch identifier <case_clause> endswitch
        RULE_CASE_CLAUSE_CASE_INT_COLON                   = 21, // <case_clause> ::= case int ':' <statement_list> <case_clause>
        RULE_CASE_CLAUSE_DEFAULT_COLON                    = 22, // <case_clause> ::= default ':' <statement_list>
        RULE_CASE_CLAUSE                                  = 23, // <case_clause> ::= 
        RULE_EXPRESSION                                   = 24, // <expression> ::= <arithmetic_expression>
        RULE_EXPRESSION2                                  = 25, // <expression> ::= <logical_expression>
        RULE_EXPRESSION3                                  = 26, // <expression> ::= <value>
        RULE_ARITHMETIC_EXPRESSION_PLUS                   = 27, // <arithmetic_expression> ::= <value> '+' <value>
        RULE_ARITHMETIC_EXPRESSION_MINUS                  = 28, // <arithmetic_expression> ::= <value> '-' <value>
        RULE_ARITHMETIC_EXPRESSION_TIMES                  = 29, // <arithmetic_expression> ::= <value> '*' <value>
        RULE_ARITHMETIC_EXPRESSION_DIV                    = 30, // <arithmetic_expression> ::= <value> '/' <value>
        RULE_LOGICAL_EXPRESSION_EQEQ                      = 31, // <logical_expression> ::= <value> '==' <value>
        RULE_LOGICAL_EXPRESSION_EXCLAMEQ                  = 32, // <logical_expression> ::= <value> '!=' <value>
        RULE_LOGICAL_EXPRESSION_LT                        = 33, // <logical_expression> ::= <value> '<' <value>
        RULE_LOGICAL_EXPRESSION_GT                        = 34, // <logical_expression> ::= <value> '>' <value>
        RULE_LOGICAL_EXPRESSION_LTEQ                      = 35, // <logical_expression> ::= <value> '<=' <value>
        RULE_LOGICAL_EXPRESSION_GTEQ                      = 36, // <logical_expression> ::= <value> '>=' <value>
        RULE_VALUE_IDENTIFIER                             = 37, // <value> ::= identifier
        RULE_VALUE_INT                                    = 38, // <value> ::= int
        RULE_VALUE_FLOAT                                  = 39, // <value> ::= float
        RULE_VALUE_STRING                                 = 40, // <value> ::= string
        RULE_VALUE_BOOLEAN                                = 41  // <value> ::= boolean
    };

    public class MyParser
    {
        private LALRParser parser;

        ListBox lst;
        ListBox ls;
        public MyParser(string filename, ListBox lst, ListBox ls)
        {
            FileStream stream = new FileStream(filename,
                                               FileMode.Open,
                                               FileAccess.Read,
                                               FileShare.Read);
            this.lst = lst;
            this.ls = ls;
            Init(stream);
            stream.Close();
        }

        public MyParser(string baseName, string resourceName)
        {
            byte[] buffer = ResourceUtil.GetByteArrayResource(
                System.Reflection.Assembly.GetExecutingAssembly(),
                baseName,
                resourceName);
            MemoryStream stream = new MemoryStream(buffer);
            Init(stream);
            stream.Close();
        }

        public MyParser(Stream stream)
        {
            Init(stream);
        }

        private void Init(Stream stream)
        {
            CGTReader reader = new CGTReader(stream);
            parser = reader.CreateNewParser();
            parser.TrimReductions = false;
            parser.StoreTokens = LALRParser.StoreTokensMode.NoUserObject;

            parser.OnTokenError += new LALRParser.TokenErrorHandler(TokenErrorEvent);
            parser.OnParseError += new LALRParser.ParseErrorHandler(ParseErrorEvent);
            parser.OnTokenRead += new LALRParser.TokenReadHandler(TokenReadEvent);
        }

        public void Parse(string source)
        {
            NonterminalToken token = parser.Parse(source);
            if (token != null)
            {
                Object obj = CreateObject(token);
                //todo: Use your object any way you like
            }
        }

        private Object CreateObject(Token token)
        {
            if (token is TerminalToken)
                return CreateObjectFromTerminal((TerminalToken)token);
            else
                return CreateObjectFromNonterminal((NonterminalToken)token);
        }

        private Object CreateObjectFromTerminal(TerminalToken token)
        {
            switch (token.Symbol.Id)
            {
                case (int)SymbolConstants.SYMBOL_EOF :
                //(EOF)
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ERROR :
                //(Error)
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_WHITESPACE :
                //Whitespace
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_MINUS :
                //'-'
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_EXCLAMEQ :
                //'!='
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_TIMES :
                //'*'
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_DIV :
                //'/'
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_COLON :
                //':'
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_SEMI :
                //';'
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_PLUS :
                //'+'
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_LT :
                //'<'
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_LTMINUS :
                //'<-'
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_LTEQ :
                //'<='
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_EQEQ :
                //'=='
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_GT :
                //'>'
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_GTEQ :
                //'>='
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_BOOLEAN :
                //boolean
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_CASE :
                //case
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_DEFAULT :
                //default
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_DO :
                //do
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ELIF :
                //elif
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ELSE :
                //else
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ENDFOR :
                //endfor
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ENDLOOP :
                //endloop
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ENDPROGRAM :
                //EndProgram
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ENDSWITCH :
                //endswitch
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ENDWHILE :
                //endwhile
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_FLOAT :
                //float
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_FOR :
                //for
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_IDENTIFIER :
                //identifier
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_IF :
                //if
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_INT :
                //int
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_LOOP :
                //loop
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_PROGRAM :
                //Program
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_STRING :
                //string
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_SWITCH :
                //switch
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_THEN :
                //then
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_TO :
                //to
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_WHILE :
                //while
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ARITHMETIC_EXPRESSION :
                //<arithmetic_expression>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ASSIGNMENT :
                //<assignment>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_CASE_CLAUSE :
                //<case_clause>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_CONDITIONAL :
                //<conditional>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_DO_WHILE_LOOP :
                //<do_while_loop>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ELIF_CLAUSE :
                //<elif_clause>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_ELSE_CLAUSE :
                //<else_clause>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_EXPRESSION :
                //<expression>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_FOR_LOOP :
                //<for_loop>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_LOGICAL_EXPRESSION :
                //<logical_expression>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_LOOP2 :
                //<loop>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_PROGRAM2 :
                //<program>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_STATEMENT :
                //<statement>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_STATEMENT_LIST :
                //<statement_list>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_SWITCH_CASE :
                //<switch_case>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_VALUE :
                //<value>
                //todo: Create a new object that corresponds to the symbol
                return null;

                case (int)SymbolConstants.SYMBOL_WHILE_LOOP :
                //<while_loop>
                //todo: Create a new object that corresponds to the symbol
                return null;

            }
            throw new SymbolException("Unknown symbol");
        }

        public Object CreateObjectFromNonterminal(NonterminalToken token)
        {
            switch (token.Rule.Id)
            {
                case (int)RuleConstants.RULE_PROGRAM_PROGRAM_ENDPROGRAM :
                //<program> ::= Program <statement_list> EndProgram
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_STATEMENT_LIST_SEMI :
                //<statement_list> ::= <statement> ';' <statement_list>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_STATEMENT_LIST :
                //<statement_list> ::= <statement>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_STATEMENT :
                //<statement> ::= <assignment>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_STATEMENT2 :
                //<statement> ::= <conditional>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_STATEMENT3 :
                //<statement> ::= <loop>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_STATEMENT4 :
                //<statement> ::= <for_loop>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_STATEMENT5 :
                //<statement> ::= <while_loop>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_STATEMENT6 :
                //<statement> ::= <do_while_loop>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_STATEMENT7 :
                //<statement> ::= <switch_case>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_ASSIGNMENT_IDENTIFIER_LTMINUS :
                //<assignment> ::= identifier '<-' <expression>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_CONDITIONAL_IF_THEN :
                //<conditional> ::= if <expression> then <statement_list> <elif_clause> <else_clause>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_ELIF_CLAUSE_ELIF_THEN :
                //<elif_clause> ::= elif <expression> then <statement_list> <elif_clause>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_ELIF_CLAUSE :
                //<elif_clause> ::= 
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_ELSE_CLAUSE_ELSE_THEN :
                //<else_clause> ::= else then <statement_list>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_ELSE_CLAUSE :
                //<else_clause> ::= 
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_LOOP_LOOP_DO_ENDLOOP :
                //<loop> ::= loop <expression> do <statement_list> endloop
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_FOR_LOOP_FOR_IDENTIFIER_LTMINUS_TO_DO_ENDFOR :
                //<for_loop> ::= for identifier '<-' <expression> to <expression> do <statement_list> endfor
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_WHILE_LOOP_WHILE_DO_ENDWHILE :
                //<while_loop> ::= while <expression> do <statement_list> endwhile
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_DO_WHILE_LOOP_DO_WHILE :
                //<do_while_loop> ::= do <statement_list> while <expression>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_SWITCH_CASE_SWITCH_IDENTIFIER_ENDSWITCH :
                //<switch_case> ::= switch identifier <case_clause> endswitch
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_CASE_CLAUSE_CASE_INT_COLON :
                //<case_clause> ::= case int ':' <statement_list> <case_clause>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_CASE_CLAUSE_DEFAULT_COLON :
                //<case_clause> ::= default ':' <statement_list>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_CASE_CLAUSE :
                //<case_clause> ::= 
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_EXPRESSION :
                //<expression> ::= <arithmetic_expression>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_EXPRESSION2 :
                //<expression> ::= <logical_expression>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_EXPRESSION3 :
                //<expression> ::= <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_ARITHMETIC_EXPRESSION_PLUS :
                //<arithmetic_expression> ::= <value> '+' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_ARITHMETIC_EXPRESSION_MINUS :
                //<arithmetic_expression> ::= <value> '-' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_ARITHMETIC_EXPRESSION_TIMES :
                //<arithmetic_expression> ::= <value> '*' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_ARITHMETIC_EXPRESSION_DIV :
                //<arithmetic_expression> ::= <value> '/' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_LOGICAL_EXPRESSION_EQEQ :
                //<logical_expression> ::= <value> '==' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_LOGICAL_EXPRESSION_EXCLAMEQ :
                //<logical_expression> ::= <value> '!=' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_LOGICAL_EXPRESSION_LT :
                //<logical_expression> ::= <value> '<' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_LOGICAL_EXPRESSION_GT :
                //<logical_expression> ::= <value> '>' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_LOGICAL_EXPRESSION_LTEQ :
                //<logical_expression> ::= <value> '<=' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_LOGICAL_EXPRESSION_GTEQ :
                //<logical_expression> ::= <value> '>=' <value>
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_VALUE_IDENTIFIER :
                //<value> ::= identifier
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_VALUE_INT :
                //<value> ::= int
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_VALUE_FLOAT :
                //<value> ::= float
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_VALUE_STRING :
                //<value> ::= string
                //todo: Create a new object using the stored tokens.
                return null;

                case (int)RuleConstants.RULE_VALUE_BOOLEAN :
                //<value> ::= boolean
                //todo: Create a new object using the stored tokens.
                return null;

            }
            throw new RuleException("Unknown rule");
        }

        private void TokenErrorEvent(LALRParser parser, TokenErrorEventArgs args)
        {
            string message = "Token error with input: '"+args.Token.ToString()+"'";
            //todo: Report message to UI?
        }

        private void ParseErrorEvent(LALRParser parser, ParseErrorEventArgs args)
        {
            string message = "Parse error caused by token: '" + args.UnexpectedToken.ToString() + "'" + args.UnexpectedToken.Location.LineNr;
            lst.Items.Add(message);
            string m2 = "Expected token:" + args.ExpectedTokens.ToString();
            lst.Items.Add(m2);
            //todo: Report message to UI?
        }
        private void TokenReadEvent(LALRParser parser, TokenReadEventArgs args)
        {
            string info = args.Token.Text + "    \t \t" + (SymbolConstants)args.Token.Symbol.Id;
            ls.Items.Add(info);
        }

    }
}
